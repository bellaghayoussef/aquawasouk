<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (Schema::hasTable('orders')) {
            Schema::table('orders', function (Blueprint $table) {
                if (!Schema::hasColumn('orders', 'paddle_transaction_id')) {
                    $table->string('paddle_transaction_id')->nullable()->after('payment_method');
                }
                if (!Schema::hasColumn('orders', 'paddle_checkout_url')) {
                    $table->text('paddle_checkout_url')->nullable()->after('paddle_transaction_id');
                }
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('orders')) {
            Schema::table('orders', function (Blueprint $table) {
                if (Schema::hasColumn('orders', 'paddle_transaction_id')) {
                    $table->dropColumn('paddle_transaction_id');
                }
                if (Schema::hasColumn('orders', 'paddle_checkout_url')) {
                    $table->dropColumn('paddle_checkout_url');
                }
            });
        }
    }
};
