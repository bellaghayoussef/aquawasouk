<?php

namespace App\Services\Paddle;

use App\Models\Order;
use App\Notifications\OrderStatusNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class PaddleService
{
    protected string $apiKey;
    protected string $clientToken;
    protected string $webhookSecret;
    protected bool $sandbox;
    protected string $baseUrl;
    protected string $currency;

    public function __construct()
    {
        $this->apiKey = (string) config('services.paddle.api_key', '');
        $this->clientToken = (string) config('services.paddle.client_token', '');
        $this->webhookSecret = (string) config('services.paddle.webhook_secret', '');
        $configuredSandbox = (bool) config('services.paddle.sandbox', true);

        // Auto-detect environment based on token prefix (live_ vs test_) to prevent 403 mismatch
        if (str_starts_with($this->clientToken, 'live_')) {
            $this->sandbox = false;
        } elseif (str_starts_with($this->clientToken, 'test_')) {
            $this->sandbox = true;
        } else {
            $this->sandbox = $configuredSandbox;
        }

        $this->baseUrl = $this->sandbox ? 'https://sandbox-api.paddle.com' : 'https://api.paddle.com';
        $this->currency = (string) config('services.paddle.currency', 'USD');
    }

    public function isConfigured(): bool
    {
        return !empty($this->clientToken);
    }

    public function getClientToken(): string
    {
        return $this->clientToken;
    }

    public function getEnvironment(): string
    {
        return $this->sandbox ? 'sandbox' : 'production';
    }

    /**
     * Create a server-side transaction for an order
     */
    public function createTransaction(Order $order, ?string $returnUrl = null): array
    {
        if (empty($this->apiKey)) {
            // If no secret API key is provided yet, fallback to client-side paddle checkout
            return [
                'success' => true,
                'client_only' => true,
                'order' => $order,
            ];
        }

        try {
            $customerEmail = $order->user ? $order->user->email : 'client_' . preg_replace('/[^0-9]/', '', $order->phone) . '@aquawasouk.com';
            $customerName = $order->user ? $order->user->name : 'Client AquawaSouk';

            // Amount in minor currency units (cents)
            $minorAmount = (string) round((float)$order->total_amount * 100);

            $payload = [
                'items' => [
                    [
                        'quantity' => 1,
                        'price' => [
                            'description' => "Commande AquawaSouk #{$order->order_number}",
                            'name' => "AquawaSouk #{$order->order_number}",
                            'unit_price' => [
                                'amount' => $minorAmount,
                                'currency_code' => $this->currency,
                            ],
                            'product' => [
                                'name' => "Commande #{$order->order_number}",
                                'tax_category' => 'standard',
                            ],
                        ],
                    ],
                ],
                'customer' => [
                    'email' => $customerEmail,
                    'name' => $customerName,
                ],
                'custom_data' => [
                    'order_id' => $order->id,
                    'order_number' => $order->order_number,
                ],
            ];

            $response = Http::withToken($this->apiKey)
                ->acceptJson()
                ->post("{$this->baseUrl}/transactions", $payload);

            if ($response->successful()) {
                $data = $response->json('data') ?? [];
                $transactionId = $data['id'] ?? null;
                $checkoutUrl = $data['checkout']['url'] ?? null;

                $order->update([
                    'paddle_transaction_id' => $transactionId,
                    'paddle_checkout_url' => $checkoutUrl,
                ]);

                return [
                    'success' => true,
                    'transaction_id' => $transactionId,
                    'checkout_url' => $checkoutUrl,
                ];
            }

            Log::error('[PaddleService] Transaction creation failed', [
                'status' => $response->status(),
                'response' => $response->body(),
            ]);

            return [
                'success' => false,
                'message' => $response->json('error.detail') ?? 'Erreur lors de la création de la transaction Paddle.',
            ];
        } catch (\Throwable $e) {
            Log::error('[PaddleService] Exception creating transaction: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Verify Paddle Webhook Signature
     */
    public function verifyWebhookSignature(Request $request): bool
    {
        if (empty($this->webhookSecret)) {
            Log::warning('[PaddleService] PADDLE_WEBHOOK_SECRET_KEY not set, skipping signature verification in test mode.');
            return true;
        }

        $signatureHeader = $request->header('Paddle-Signature');
        if (empty($signatureHeader)) {
            return false;
        }

        // Format: ts=12345678;h1=abcdef...
        $parts = [];
        foreach (explode(';', $signatureHeader) as $segment) {
            $kv = explode('=', $segment, 2);
            if (count($kv) === 2) {
                $parts[trim($kv[0])] = trim($kv[1]);
            }
        }

        if (!isset($parts['ts']) || !isset($parts['h1'])) {
            return false;
        }

        $ts = $parts['ts'];
        $receivedHash = $parts['h1'];
        $rawPayload = $request->getContent();

        $expectedHash = hash_hmac('sha256', "{$ts}:{$rawPayload}", $this->webhookSecret);

        return hash_equals($expectedHash, $receivedHash);
    }

    /**
     * Process Paddle Webhook Events
     */
    public function handleWebhook(array $payload): array
    {
        $eventType = $payload['event_type'] ?? '';
        $data = $payload['data'] ?? [];

        Log::info("[PaddleService] Received webhook event: {$eventType}", ['event_id' => $payload['event_id'] ?? null]);

        if (in_array($eventType, ['transaction.completed', 'transaction.paid'])) {
            $transactionId = $data['id'] ?? null;
            $customData = $data['custom_data'] ?? [];
            $orderId = $customData['order_id'] ?? null;

            $order = null;
            if ($orderId) {
                $order = Order::find($orderId);
            } elseif ($transactionId) {
                $order = Order::where('paddle_transaction_id', $transactionId)->first();
            }

            if ($order) {
                $oldStatus = $order->status;
                $order->update([
                    'payment_status' => 'paid',
                    'payment_method' => 'paddle',
                    'status' => 'processing',
                    'paddle_transaction_id' => $transactionId ?? $order->paddle_transaction_id,
                ]);

                // Update items status
                $order->items()->update(['status' => 'processing']);

                // Notify customer in-app & email
                try {
                    if ($order->user) {
                        $order->user->notify(new OrderStatusNotification($order, $oldStatus, 'processing'));
                    }
                } catch (\Throwable $e) {}

                Log::info("[PaddleService] Order #{$order->order_number} marked as PAID via Paddle.");

                return ['success' => true, 'order_id' => $order->id];
            }
        }

        return ['success' => true, 'ignored' => true];
    }
}
