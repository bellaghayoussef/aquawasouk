<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Cart;
use App\Models\Order;
use App\Services\Paddle\PaddleService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class PaddlePaymentController extends Controller
{
    protected PaddleService $paddle;

    public function __construct(PaddleService $paddle)
    {
        $this->paddle = $paddle;
    }

    /**
     * Show Paddle Checkout (Web and Mobile In-App WebView)
     */
    public function checkout(Order $order, Request $request)
    {
        // If order already paid, redirect to tracking
        if ($order->payment_status === 'paid') {
            return redirect()->route('orders.track', ['order' => $order->order_number])
                ->with('success', __('Cette commande a déjà été payée avec succès.'));
        }

        $appRedirect = $request->query('app_redirect'); // e.g. aquado://payment/success

        // Create transaction on Paddle or get transaction ID
        $txResult = $this->paddle->createTransaction($order);

        $navCategories = Category::where('parent_id', null)->take(8)->get();
        $cartCount = 0;
        if (auth()->check()) {
            $cart = Cart::where('user_id', auth()->id())->first();
            $cartCount = $cart ? (int) $cart->items()->sum('quantity') : 0;
        }

        return view('blade.checkout.paddle', [
            'order' => $order->load(['items.product', 'user']),
            'clientToken' => $this->paddle->getClientToken(),
            'environment' => $this->paddle->getEnvironment(),
            'transactionId' => $txResult['transaction_id'] ?? $order->paddle_transaction_id,
            'checkoutUrl' => $txResult['checkout_url'] ?? $order->paddle_checkout_url,
            'appRedirect' => $appRedirect,
            'navCategories' => $navCategories,
            'cartCount' => $cartCount,
        ]);
    }

    /**
     * Payment Success callback page
     */
    public function success(Order $order, Request $request)
    {
        // Update to paid if verified via query
        if ($request->filled('_ptxn')) {
            $order->update([
                'paddle_transaction_id' => $request->query('_ptxn'),
                'payment_status' => 'paid',
                'payment_method' => 'paddle',
                'status' => 'processing',
            ]);
        }

        $appRedirect = $request->query('app_redirect');
        if (!empty($appRedirect)) {
            // Redirect back to mobile Flutter app via custom scheme
            return redirect()->away("{$appRedirect}?order={$order->order_number}&status=paid");
        }

        return view('blade.checkout.success', [
            'order' => $order->load(['items.product', 'user']),
            'navCategories' => Category::where('parent_id', null)->take(8)->get(),
            'cartCount' => 0,
        ]);
    }

    /**
     * Webhook Handler for Paddle Events (Server to Server)
     */
    public function webhook(Request $request)
    {
        if (!$this->paddle->verifyWebhookSignature($request)) {
            Log::warning('[PaddleWebhook] Invalid signature received from IP: ' . $request->ip());
            return response()->json(['error' => 'Invalid signature'], 401);
        }

        $payload = $request->all();
        $result = $this->paddle->handleWebhook($payload);

        return response()->json([
            'received' => true,
            'result' => $result,
        ]);
    }
}
