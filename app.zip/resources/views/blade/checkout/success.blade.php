@extends('blade.layout')

@section('title', 'Paiement Réussi - Commande #' . $order->order_number)
@section('meta_description', 'Votre paiement en ligne a été confirmé avec succès sur AquawaSouk.')

@section('content')
@php
    $isAr = app()->getLocale() === 'ar';
    $currency = $isAr ? 'د.ت' : 'DT';
@endphp

<div class="bg-slate-50/70 py-12 min-h-[75vh] flex items-center justify-center">
    <div class="max-w-xl w-full mx-4">
        
        <div class="bg-white rounded-3xl p-8 sm:p-10 border border-slate-200/80 shadow-xl text-center">
            
            <!-- Celebration Badge -->
            <div class="w-20 h-20 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-4xl mx-auto mb-6 shadow-md shadow-emerald-500/20 animate-bounce">
                ✓
            </div>

            <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-emerald-50 text-emerald-800 border border-emerald-200 uppercase tracking-wider mb-2">
                💳 {{ $isAr ? 'تم تأكيد الدفع بنجاح' : 'Paiement Confirmé via Paddle' }}
            </span>

            <h1 class="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mb-2">
                {{ $isAr ? 'شكراً لثقتكم !' : 'Merci pour votre commande !' }}
            </h1>

            <p class="text-xs sm:text-sm text-slate-500 mb-6">
                {{ $isAr ? 'تم استلام الدفع بنجاح وتم تحويل الطلبية مباشرة إلى البائع للتجهيز والشحن.' : 'Votre transaction a été validée. Votre commande est immédiatement transmise au vendeur pour expédition rapide.' }}
            </p>

            <!-- Order info box -->
            <div class="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 text-left rtl:text-right space-y-2.5 text-xs mb-8">
                <div class="flex justify-between items-center pb-2 border-b border-slate-200">
                    <span class="text-slate-500">{{ $isAr ? 'رقم الطلبية' : 'Numéro de commande' }} :</span>
                    <strong class="text-sky-600 font-extrabold text-sm">#{{ $order->order_number }}</strong>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-slate-500">{{ $isAr ? 'المبلغ المدفوع' : 'Montant réglé' }} :</span>
                    <strong class="text-slate-900 text-sm font-black">{{ number_format($order->total_amount, 2) }} {{ $currency }}</strong>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-slate-500">{{ $isAr ? 'طريقة الدفع' : 'Mode de paiement' }} :</span>
                    <span class="inline-flex items-center gap-1 font-bold text-slate-800">
                        <span>💳</span> Carte Bancaire (Paddle)
                    </span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-slate-500">{{ $isAr ? 'العنوان' : 'Livraison à' }} :</span>
                    <span class="font-bold text-slate-800">{{ $order->shipping_city }}, Tunisie</span>
                </div>
            </div>

            <!-- Action buttons -->
            <div class="flex flex-col sm:flex-row items-center justify-center gap-3">
                <a 
                    href="{{ route('orders.track', ['order' => $order->order_number]) }}" 
                    class="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-black text-xs uppercase tracking-wider shadow-md transition transform active:scale-95"
                >
                    🚚 {{ $isAr ? 'تتبع مسار التوصيل' : 'Suivre ma commande en direct' }}
                </a>
                <a 
                    href="{{ route('products.index') }}" 
                    class="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition"
                >
                    {{ $isAr ? 'العودة للمتجر' : 'Continuer mes achats' }}
                </a>
            </div>

        </div>

    </div>
</div>
@endsection
