@extends('blade.layout')

@section('title', 'Paiement Sécurisé Paddle - Commande #' . $order->order_number)
@section('meta_description', 'Paiement en ligne sécurisé par Carte Bancaire via Paddle pour votre commande AquawaSouk.')

@push('styles')
<style>
    .paddle-checkout-container {
        min-height: 480px;
    }
</style>
@endpush

@section('content')
@php
    $isAr = app()->getLocale() === 'ar';
    $currency = $isAr ? 'د.ت' : 'DT';
@endphp

<div class="bg-slate-50/70 py-8 sm:py-12 min-h-[80vh]">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">

        <!-- Top breadcrumb & security badges -->
        <div class="flex flex-wrap items-center justify-between gap-4 mb-8">
            <div class="flex items-center gap-2 text-xs text-slate-500">
                <a href="{{ route('home') }}" class="hover:text-sky-600 font-medium">{{ __('messages.home') }}</a>
                <span>&rarr;</span>
                <span class="text-slate-900 font-bold">{{ $isAr ? 'الدفع الإلكتروني' : 'Paiement Sécurisé' }}</span>
                <span>&rarr;</span>
                <span class="text-sky-600 font-extrabold">{{ $order->order_number }}</span>
            </div>

            <div class="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold">
                <span>🔒</span>
                <span>{{ $isAr ? 'دفع إلكتروني محمي بتشفير 256-bit SSL' : 'Paiement crypté & sécurisé par Paddle' }}</span>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- Left: Order Summary details -->
            <div class="lg:col-span-5 space-y-5">
                <div class="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-md">
                    <h3 class="text-sm font-black text-slate-900 uppercase tracking-wider mb-4 pb-3 border-b border-slate-100 flex items-center justify-between">
                        <span>{{ $isAr ? 'ملخص الطلبية' : 'Récapitulatif Commande' }}</span>
                        <span class="text-xs text-sky-600 font-bold">#{{ $order->order_number }}</span>
                    </h3>

                    <!-- Items list -->
                    <div class="space-y-3 max-h-60 overflow-y-auto pr-1">
                        @foreach($order->items as $item)
                            @php $p = $item->product; @endphp
                            <div class="flex items-center gap-3 text-xs">
                                @if($p)
                                    <img src="{{ $p->image_url }}" alt="{{ $p->name }}" class="w-12 h-12 rounded-xl object-cover bg-slate-50 shrink-0 border border-slate-100">
                                @endif
                                <div class="flex-1 min-w-0">
                                    <p class="font-bold text-slate-900 truncate">{{ $p ? $p->name : 'Produit' }}</p>
                                    <span class="text-[11px] text-slate-500">Qté: {{ $item->quantity }} × {{ number_format($item->price, 2) }} {{ $currency }}</span>
                                </div>
                                <span class="font-black text-slate-900">
                                    {{ number_format($item->quantity * $item->price, 2) }} {{ $currency }}
                                </span>
                            </div>
                        @endforeach
                    </div>

                    <!-- Price breakdown -->
                    <div class="pt-4 border-t border-slate-100 space-y-2 text-xs text-slate-600">
                        <div class="flex justify-between">
                            <span>{{ $isAr ? 'تكلفة التوصيل' : 'Frais de livraison' }} :</span>
                            <span class="font-bold text-slate-900">{{ number_format($order->shipping_cost, 2) }} {{ $currency }}</span>
                        </div>
                        @if($order->discount_amount > 0)
                            <div class="flex justify-between text-emerald-600 font-bold">
                                <span>{{ $isAr ? 'تخفيض الكوبون' : 'Remise code promo' }} :</span>
                                <span>-{{ number_format($order->discount_amount, 2) }} {{ $currency }}</span>
                            </div>
                        @endif
                        <div class="pt-2 border-t border-slate-200 flex items-baseline justify-between text-base font-black text-slate-900">
                            <span>{{ $isAr ? 'المجموع النهائي' : 'Total à régler' }} :</span>
                            <span class="text-xl text-sky-600">{{ number_format($order->total_amount, 2) }} {{ $currency }}</span>
                        </div>
                    </div>
                </div>

                <!-- Client delivery info -->
                <div class="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-2xs text-xs space-y-1">
                    <p class="font-bold text-slate-900">📍 {{ $order->user ? $order->user->name : 'Client' }}</p>
                    <p class="text-slate-600">{{ $order->shipping_address }}, {{ $order->shipping_city }}</p>
                    <p class="text-slate-600">📞 {{ $order->phone }}</p>
                </div>
            </div>

            <!-- Right: Paddle.js Embedded / Checkout Container -->
            <div class="lg:col-span-7">
                <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-lg">
                    
                    <div class="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-2xl bg-sky-50 text-sky-600 font-black text-xl flex items-center justify-center">
                                💳
                            </div>
                            <div>
                                <h2 class="text-base font-black text-slate-900">
                                    {{ $isAr ? 'الدفع بالبطاقة البنكية' : 'Paiement par Carte Bancaire' }}
                                </h2>
                                <p class="text-xs text-slate-500">
                                    {{ $isAr ? 'معالجة فورية ومؤمنة عبر Paddle Payments' : 'Transactions sécurisées via le réseau Paddle' }}
                                </p>
                            </div>
                        </div>

                        <!-- Card brand icons -->
                        <div class="flex items-center gap-1.5 opacity-80">
                            <span class="px-2 py-1 rounded bg-slate-100 font-extrabold text-[10px] text-slate-700">VISA</span>
                            <span class="px-2 py-1 rounded bg-slate-100 font-extrabold text-[10px] text-slate-700">MC</span>
                            <span class="px-2 py-1 rounded bg-slate-100 font-extrabold text-[10px] text-slate-700">AMEX</span>
                        </div>
                    </div>

                    <!-- Paddle checkout mount node -->
                    <div class="paddle-checkout-frame paddle-checkout-container w-full min-h-[480px] rounded-2xl relative" id="paddle-checkout-frame">
                        <div id="paddle-loading" class="flex flex-col items-center justify-center py-16 text-center text-slate-400">
                            <div class="w-10 h-10 border-4 border-sky-600 border-t-transparent rounded-full animate-spin mb-4"></div>
                            <p class="text-xs font-semibold text-slate-600">
                                {{ $isAr ? 'جاري تهيئة نافذة الدفع الآمن...' : 'Chargement du module de paiement sécurisé Paddle...' }}
                            </p>
                        </div>
                    </div>

                    <!-- Paddle Error Warning Box (if 403 / unapproved domain / CSP) -->
                    <div id="paddle-error-box" class="hidden mt-4 p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-800 text-xs">
                        <div class="flex items-start gap-3">
                            <span class="text-base">⚠️</span>
                            <div class="space-y-1">
                                <p class="font-bold">{{ $isAr ? 'تنبيه بوابة Paddle' : 'Information Paddle' }}</p>
                                <p class="text-[11px] text-amber-700">
                                    {{ $isAr ? 'إذا كان المتجر قيد التطوير المحلي (127.0.0.1)، يجب تسجيل النطاق في لوحة تحكم Paddle أو استخدام نافذة الدفع الخارجية.' : 'Si vous testez en local (127.0.0.1), Paddle vérifie l\'approbation du domaine. Vous pouvez utiliser le bouton direct ou la simulation ci-dessous.' }}
                                </p>
                            </div>
                        </div>
                    </div>

                    <!-- Fallback Direct Button if script blocked or popup preferred -->
                    <div id="paddle-fallback-btn" class="mt-4 space-y-3 text-center">
                        <button 
                            type="button" 
                            id="btn-open-paddle"
                            class="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-black text-sm uppercase tracking-wider shadow-lg shadow-sky-600/30 transition transform active:scale-98 cursor-pointer flex items-center justify-center gap-2"
                        >
                            <span>🔒</span>
                            <span>{{ $isAr ? 'فتح نافذة الدفع الآمنة' : 'Ouvrir la fenêtre sécurisée Paddle' }} ({{ number_format($order->total_amount, 2) }} {{ $currency }})</span>
                        </button>

                        @if(app()->environment('local', 'testing') || str_contains(request()->getHost(), '127.0.0.1') || str_contains(request()->getHost(), 'localhost'))
                            <!-- Dev Test Payment Simulator for Order #{{ $order->order_number }} -->
                            <div class="pt-3 border-t border-slate-100">
                                <a 
                                    href="{{ route('paddle.success', $order->id) }}?_ptxn=dev_sim_{{ time() }}{{ $appRedirect ? '&app_redirect=' . urlencode($appRedirect) : '' }}"
                                    class="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition"
                                >
                                    <span>🧪 Mode Test Local : Valider la commande directement</span>
                                    <span class="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px]">Dev</span>
                                </a>
                            </div>
                        @endif
                    </div>

                </div>
            </div>

        </div>

    </div>
</div>

@push('scripts')
<!-- Paddle.js v2 SDK -->
<script src="https://cdn.paddle.com/paddle/v2/paddle.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const clientToken = "{{ $clientToken }}";
    const environment = "{{ $environment }}";
    const transactionId = "{{ $transactionId }}";
    const orderId = "{{ $order->id }}";
    const orderNumber = "{{ $order->order_number }}";
    const appRedirect = "{{ $appRedirect }}";
    const successUrl = "{{ route('paddle.success', $order->id) }}" + (appRedirect ? '?app_redirect=' + encodeURIComponent(appRedirect) : '');

    if (!window.Paddle) {
        console.error('Paddle.js failed to load');
        const loadElem = document.getElementById('paddle-loading');
        if (loadElem) loadElem.innerHTML = '<p class="text-rose-600 text-xs font-bold">Impossible de charger le module Paddle. Vérifiez votre connexion internet.</p>';
        return;
    }

    try {
        // Environment handling: Only call set('sandbox') if token starts with test_ or environment is explicitly sandbox without a live_ key
        if (clientToken.startsWith('test_') || (environment === 'sandbox' && !clientToken.startsWith('live_'))) {
            Paddle.Environment.set('sandbox');
        }

        Paddle.Initialize({
            token: clientToken,
            eventCallback: function (data) {
                console.log('[Paddle Event]', data?.name, data);
                if (data?.name === 'checkout.completed') {
                    // Payment succeeded!
                    window.location.href = successUrl + (successUrl.includes('?') ? '&' : '?') + '_ptxn=' + (data.data?.transaction_id || '');
                } else if (data?.name === 'checkout.error' || data?.name === 'checkout.failed') {
                    document.getElementById('paddle-error-box')?.classList.remove('hidden');
                }
            }
        });

        // Hide loading placeholder
        setTimeout(function() {
            document.getElementById('paddle-loading')?.remove();
        }, 800);

        const openCheckout = function(isOverlay) {
            const checkoutSettings = {
                settings: {
                    displayMode: isOverlay ? 'overlay' : 'inline',
                    frameTarget: 'paddle-checkout-frame',
                    frameInitialHeight: 480,
                    frameStyle: 'width: 100%; min-width: 312px; background-color: transparent; border: none;',
                    successUrl: successUrl,
                },
                customer: {
                    email: "{{ $order->user ? $order->user->email : '' }}",
                },
                customData: {
                    order_id: orderId,
                    order_number: orderNumber,
                }
            };

            if (transactionId) {
                checkoutSettings.transactionId = transactionId;
            } else {
                checkoutSettings.items = [
                    {
                        quantity: 1,
                        price: {
                            description: "Commande AquawaSouk #" + orderNumber,
                            unitPrice: {
                                amount: "{{ round((float)$order->total_amount * 100) }}",
                                currencyCode: "{{ config('services.paddle.currency', 'USD') }}"
                            },
                            product: {
                                name: "Commande #" + orderNumber
                            }
                        }
                    }
                ];
            }

            try {
                Paddle.Checkout.open(checkoutSettings);
            } catch (err) {
                console.error('[Paddle Checkout Open Error]', err);
                document.getElementById('paddle-error-box')?.classList.remove('hidden');
            }
        };

        // Open inline checkout
        openCheckout(false);

        // Bind overlay fallback button
        document.getElementById('btn-open-paddle')?.addEventListener('click', function() {
            openCheckout(true);
        });

    } catch (e) {
        console.error('Paddle Initialization error:', e);
        document.getElementById('paddle-error-box')?.classList.remove('hidden');
        document.getElementById('btn-open-paddle')?.addEventListener('click', function() {
            Paddle.Checkout.open({
                settings: { displayMode: 'overlay', successUrl: successUrl },
                transactionId: transactionId
            });
        });
    }
});
</script>
@endpush

@endsection
