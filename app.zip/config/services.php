<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'google' => [
        'client_id' => env('GOOGLE_CLIENT_ID'),
        'client_secret' => env('GOOGLE_CLIENT_SECRET'),
        'redirect' => env('GOOGLE_REDIRECT_URI', env('APP_URL').'/auth/google/callback'),
    ],

    'meta' => [
        'verify_token' => env('META_VERIFY_TOKEN', 'aquawasouk_social_token_2026'),
        'facebook_page_token' => env('META_FACEBOOK_PAGE_TOKEN'),
        'instagram_access_token' => env('META_INSTAGRAM_ACCESS_TOKEN'),
    ],

    'paddle' => [
        'api_key' => env('PADDLE_API_KEY'),
        'client_token' => env('PADDLE_CLIENT_TOKEN', 'live_c3a07c3070445d4705a62e088d8'),
        'webhook_secret' => env('PADDLE_WEBHOOK_SECRET_KEY'),
        'sandbox' => env('PADDLE_SANDBOX', true),
        'currency' => env('PADDLE_CURRENCY', 'USD'), // Paddle Billing currency (USD, EUR, etc.)
    ],

];
